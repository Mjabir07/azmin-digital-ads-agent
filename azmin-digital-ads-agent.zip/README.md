# AZMIN DIGITAL Ads Agent

AI marketing agent that runs and reports on Meta Click-to-WhatsApp ads for AZMIN DIGITAL's
website design services (UAE, then KSA). Runs fully in the cloud: GitHub + GitHub Actions +
Google Sheets. Every money decision needs human approval.

- New here? Read `START_HERE.md`.
- Project rules for Claude Code: `CLAUDE.md`
- Strategy: `docs/PLAYBOOK.md` · System design: `docs/SPEC.md` · Setup: `docs/SETUP.md`
